// RESPON AKSES
global.mess = {
sukses: '*[ Loaded Success ]*',
admin: '*[ System Notice ]* for *admin!* not *npc*',
botAdmin: '*[ System Notice ]* please add bot *admin*',
owner: '*[ Access Failed ]* Access Denied',
group: '*[ System Notice ]* Use this in group chat!',
private: '*[ System Notice ]* Use this in private chat!',
bot: '*[ System Notice ]* Only Bot user',
error: '*[ System Failed ]* Error, please contact the owner',
wait: '*[ Loading ]* Please Wait',
limit: 'Ups limit anda habis (⁠っ⁠˘̩⁠╭⁠╮⁠˘̩⁠)⁠っ\nbeli akses sewa group untuk mendapatkan unlimited limit dan akses owner',
prem: '*[ System Notice ]* this only premium user' }

// MADE BY DARWIN HITAM 