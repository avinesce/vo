// Mas Darwin Bikin ☝🏾😜

// PANEL KEY
// pltc key
global.apicred = 'ptlc_wWsxCR4mXap4M0z7OR5oc2Mu8B6EFvtCO9C9i06hWPj'
// plta key
global.apiuser = 'ptla_JUCwsucuBWridPCT310gLB5QdP7kpHmV9V2Uy07IA4R'
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

// SETTING APIKEY OPENAI & FILESTACK
global.fileStackApi = `AK5imWKw4QMeyD0g2ij2oz` // opsional - daftar di filestack

// APIKEY
global.skyzo = `Homok`
global.lolkey = 'Darwis'
global.zeeone = `QIO8xicLNkEV43Y`

// EMAIL
global.passmail = 'liwmgvhrhjahglgl' // optional, features not yet published for version 2.7